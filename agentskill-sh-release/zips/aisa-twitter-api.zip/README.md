# AIsa Twitter API

GitHub-ready release package prepared specifically for agentskill.sh import and refresh.

## Notes

- Twitter/X research, monitoring, watchlists, and OAuth-approved posting through AIsa. Use when: the user needs one flagship Twitter skill for trend tracking, competitor monitoring, timeline analysis, watchlist review, or approved posting through the relay without sharing passwords. Supports relay-based reads, search, watchlists, and OAuth-gated text or media posting through https://api.aisa.one.
- This directory keeps one root-level skill per folder so agentskill.sh can scan the repository cleanly.
- The same skill can also be submitted by direct `SKILL.md` URL when needed.
