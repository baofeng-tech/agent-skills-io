# Prediction Market Data

GitHub-ready Agent Skills release package for AgentSkills-compatible marketplaces.

## Notes

- Prediction market data for Polymarket and Kalshi, including markets, prices, positions, trades, orderbooks, and cross-platform matching. Use when: the user needs market data, stock analysis, watchlists, or portfolio workflows.
- This release keeps the standard `SKILL.md` + `scripts/` + `references/` shape for GitHub indexing and ZIP export.
- Publish each skill as a root-level directory in a public repository for best marketplace pickup.
